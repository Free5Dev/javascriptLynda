var a = 2;
var b = 7;

console.log(a+b);
