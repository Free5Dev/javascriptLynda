var playerName = "Fred";
var playerScore = 10000;
var playerRank = 1;
