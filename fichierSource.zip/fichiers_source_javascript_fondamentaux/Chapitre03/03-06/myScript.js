var phrase = "Une simple phrase.";


console.log(phrase);



