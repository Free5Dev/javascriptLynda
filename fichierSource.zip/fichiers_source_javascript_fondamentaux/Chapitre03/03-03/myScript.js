var a=2.6, b=7, c=10;

var myNumber;

console.log(myNumber);

