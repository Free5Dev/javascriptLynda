var today;

console.log(today);

