//**************************************
//Valeurs par défaut pour les fonctions
//**************************************

function addNumbers(a, b){
    return a + b;
}

//console.log(addNumbers());

//**************************************
//Opérateur "spread"
//**************************************

var array1 = ["Rouge", "Vert", "Bleu"];
var array2 = ["Voiture", "Train", "Avion"];
var array3 = ["Entrée", "Plat", "Dessert"];

var arrayFull = [array1, array2,array3];

//console.log(arrayFull);

//**************************************
//Template strings
//**************************************

var firstName = "Damien";
var lastName = "Bruyndonckx";

//console.log("Mon prénom est "+firstName+" et mon nom de famille est "+lastName+".");
