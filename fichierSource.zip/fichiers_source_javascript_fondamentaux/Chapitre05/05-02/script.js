
//document.onclick = function() {
//	alert("Vous avez cliqué dans le document");
//};

//	var myImage = document.getElementById("mainImage");
//	myImage.onclick =  function() {
//		alert("Vous avez cliqué sur l'image");
//	}

//window.onload = function() {
	// Préparer ce dont on a besoin
//	prepareEventHandlers();
//};
