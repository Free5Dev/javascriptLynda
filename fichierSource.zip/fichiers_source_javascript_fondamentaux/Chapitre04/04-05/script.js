//Créer les éléments
//var newHeading = document.createElement("h1");
//var newParagraph = document.createElement("p");

// Pour ajouter du contenu, on peut utiliser innerHtml()
//newHeading.innerHTML = "Le saviez-vous ?";
//newParagraph.innerHTML = "La Californie produit plus de 17 millions de gallons de vin chaque année !";

// OU, créer les noeuds de texte manuellement
//var h1Text = document.createTextNode("Le saviez-vous ?");
//var paraText = document.createTextNode("La Californie produit plus de 17 millions de gallons de vin chaque année !");
// Et ajoutez-les en tant que noeuds enfants des nouveaux éléments 
//newHeading.appendChild(h1Text);
//newParagraph.appendChild(paraText);

// Pour terminer, attacher les éléments créés au document
//document.getElementById("trivia").appendChild(newHeading);
//document.getElementById("trivia").appendChild(newParagraph);
