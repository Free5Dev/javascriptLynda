if(navigator.userAgent.indexOf('Netscape') != -1){
    alert("Vous utilisez Netscape !");
}
if(navigator.appName == "Microsoft Internet Explorer"){
    alert("Vous utilisez Internet Explorer !");
}