// On n'a pas utilisé var
var foo = "Bonjour le monde !";

// Fonction avec le même nom pour plusieurs paramètres
function myFunction(a,b,a) {
   return a + b + c;
}

document.getElementById("mainContent").innerHTML = foo;

