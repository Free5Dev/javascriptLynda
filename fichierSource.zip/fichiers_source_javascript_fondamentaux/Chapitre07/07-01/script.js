//****************************************************************
//1) Utiliser le camelCase pour nommer vos variables et fonctions
//****************************************************************
//JavaScript dit : lettres, nombres, $ et _
var dghui__$$$_dfgbio = 10;

//On Nomme les fonctions de la même façon et on commence par un verbe
function checkData(){
    
}

//Les fonctions du DOM utilisent le camelCase également
document.getElementById();

//*******************************************************************
//2) Placer vos accolades sur la même ligne
//*******************************************************************
//Rappelez-vous du if
if(score > 50){
    alert("Bravo !");
}
//Même chose pour les boucles while et for
while(){
    
}

//Même chose pour les fonctions
function doSomething(){
    
}

//*******************************************************************
//3) Délimitez TOUJOURS vos blocs de code
//*******************************************************************
if(score > 50){
    alert("Bravo !");
}

//*******************************************************************
//4) Utilisez TOUJOURS le point-virgule à la fin de vos instructions
//*******************************************************************

alert("Bravo !");


