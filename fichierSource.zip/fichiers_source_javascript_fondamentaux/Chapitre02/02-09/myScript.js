var a = 2 , b = 3;


var result = a + b;
console.log(result);
