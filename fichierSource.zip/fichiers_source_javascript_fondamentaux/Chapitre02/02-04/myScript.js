//envoyer une alerte à l'écran
alert("Bonjour tout le monde !");